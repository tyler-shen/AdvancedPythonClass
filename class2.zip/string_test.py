s1 = 'Abcdefghijklmn'

# string is unmutable
# s1[0] = 'b'

# get item using index
# print(s1[0])

# check if char is in the string
# print('a' in s1)

# get sub string
# print(s1[1:3])

# mrege 2 string
s2 = 'Alslslsls'
# print(s1+s2)

# repeat string
# print(s2*5)

#########################
# s1.insert(0, 'a')

# sub string / slice always increase
# print(s1[-3:-1])
# print(s1[-1:-3])

# s3 = """Twinkle Twinkle little start
# How I wonder what you are
# """
# print(s1 > s2)

# s3 = 'I\'m tom'
# print(s3)

# s4 = "5'9\""
# print(s4)

# escape
# s5 = "I want a \\\\a new line\nsss\tslslsls\tslslslsl"
# print(s5)

print("\u2705")