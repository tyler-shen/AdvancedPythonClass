s = {1, 32, 23, 14, 5, 6, 17, 8, 91 , 10}
print(s)
# index doesn't any more
# print(s[0])

# check if item is in the set
# print(6 in s)

# add value in the set
# s.add(6)

# remove item in the set
# s.remove(2)

# pop item from a set (arbitrary)
# v = s.pop()

# clean up everything
# s.clear()

# print(s)