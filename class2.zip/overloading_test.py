# def plus(a, b):
#   return a+b

# def plus(a, b, c):
#   return a+b+c

# print(plus(3, 4, 5))

#####################
def plus(a: str, b: str):
  return a+b

def plus(a: int, b: int):
  return a+b

print(plus(3, 4))
print(plus("apple", "bee"))