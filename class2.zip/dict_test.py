# d = {'apple': 1, 'pear': 2, 'banana':2, 'orange': 5}

# define a dictionary of kvp of name: age
# d = {'alpha': 10, 'beta': 12, 'gamma': 13, 'theta': 5}

# school dictionary, value if a tuple of (age, grade, gender, mark)
d = {'Tom': (12, 5, True, 89), 'Emily': (13, 6, False, 95), 'Sam': (40, None, True, None)}
# print(d)

# check if a key is in dictionary
# print('Tom' in d)


# delete 'Emily'
# del d['Emily']

# add/update
# d['Bill'] = 5
# d['Bill'] = (18, 10, True, 50)
# print(d)

# items view for dictionary
# itemView = d.items()
# print(itemView)

# keys of dictionary
# keys = d.keys()
# print(keys)

# values of dictionary
values = d.values()
print(values)