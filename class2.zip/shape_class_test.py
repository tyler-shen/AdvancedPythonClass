# define a coordinate class, 
# define function to get the distance from the origin

# define rectangle class
# define function to calcualte the perimeter, area

# define circle class
# define function to calcualte the perimeter, area

# define triangle class
# define function to calcualte the perimeter, area
