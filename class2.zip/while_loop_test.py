# for i in range(10):
# 	print(i)

# increase the number in the while loop, and check i with 10
# i = 0
# while i < 10:
# 	print(i)
# 	i += 1

import random

# update the num inside the while loop and check num with 5
# num = 0
# while  num != 5:
# 	num = random.randint(0, 10)
# 	print(num)

# update the num1, num2 inside the while loop and check num1 with num2
num1 = 0
num2 = 1
while num1 != num2:
	num1 = random.randint(0, 10)
	num2 = random.randint(0, 10)
	print(f"num1: {num1}, num2: {num2}")