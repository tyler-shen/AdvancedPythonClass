a = 7
print(type(a))

print(a)

l = [1, 2, 3, 43, 5]
print(l)