# import os

file = open("test.txt","w")  # w - write
file.write('line1\n')
file.write('line2\n')
file.write('line3')
file.close()
