s = 'I want a banana'
# insert '-' between each char
# I_want_a_banana
s2 = s.split(' ') # convert a string into list, using specified delimiter
print(' '.join(s2))  # convert list into string, using specified delimiter