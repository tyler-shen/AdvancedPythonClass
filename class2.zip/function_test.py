def grade_a_mark(mark): # mark is argument
    return 'A'

grade = grade_a_mark(100) # 100 is parameter
print(grade)