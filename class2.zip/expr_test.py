from my_lib import evaluation
from my_lib.my_sqrt import my_sqrt as sqrt

print(evaluation.my_eval('3+4*5-3/8+2'))

print(sqrt(4))