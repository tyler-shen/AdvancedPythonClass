t1 = (1, 2, 3, 4, 5)

t2 = ('apple', 'orange', 'banana', 'watermelon')

t3 = (1, 3, 2, 4)

# # get item using index
# print(t[0])

# # check if item is in the list
# print(6 in t)

# # get sub list
# print (t[1:3])

# # merge 2 list
# print(t2+t3)

# # repeat list
# print(t2*5)

# t[0] = 100

print(t1<t3)