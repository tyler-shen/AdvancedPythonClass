l = [1, 32, 23, 14, 5, 6, 17, 8, 91 , 10]

l2 = ['apple', 'orange', 'banana', 'watermelon']

l3 = [1, 'apple', 2, 'orange']


# # get item using index
# print(l[0])

# # check if item is in the list
# print(6 in l)

# # get sub list
# print (l[1:3])

# # merge 2 list
# print(l2+l3)

# # repeat list
# print(l2*5)

# ########## this is goint to be muted########
# l[0] = 100

# # print(l)
# # this is add the item at the end of the list
# l.append(101)

# print(l)
# l.insert(0, 99)
# print(l)

# t3 = (1, 'apple', 2, 'orange')

# l.extend(t3)

# l = list(l)

# l.remove(1)
# l.remove(1)
# l.remove(1)
# v = l.pop(0)

# clean up everything
l.clear()

print(l)